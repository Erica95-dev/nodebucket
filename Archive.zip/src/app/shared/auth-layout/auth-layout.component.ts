/*Title: auth-layout
 * Author: Erica Perry
 * Date:3/25/21
 * Description: auth
 */

/*
* import
* export class
*/

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auth-layout',
  templateUrl: './auth-layout.component.html',
  styleUrls: ['./auth-layout.component.css']
})
export class AuthLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
