export interface Item{
    _id: string;
    text: string;
    
}