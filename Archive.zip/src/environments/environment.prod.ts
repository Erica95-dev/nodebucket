/*
Title: environment
 * Author: Erica Perry
 * Date:3/25/21
 * Description: benvir
 */

/* const exported */
export const environment = {
  production: true
};
